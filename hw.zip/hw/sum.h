#include <cstdint>
#ifndef SUM_H
#define SUM_H

int64_t Sum(int64_t x, int64_t y);

#endif
