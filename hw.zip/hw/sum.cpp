#include "sum.h"

int64_t Sum(int64_t x, int64_t y) {
  return x + y;
}
